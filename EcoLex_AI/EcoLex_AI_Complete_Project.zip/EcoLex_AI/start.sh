#!/usr/bin/env bash
# Starts EcoLex AI on your Mac. Run from the EcoLex_AI folder: ./start.sh
set -e
cd "$(dirname "$0")"

PY=""
for c in python3.12 python3.13 python3.11; do
  if command -v "$c" >/dev/null 2>&1; then PY="$c"; break; fi
done
if [ -z "$PY" ]; then
  echo "Python 3.11, 3.12 or 3.13 is required (newer versions such as 3.14/3.15 are not supported yet)."
  echo "Install Python 3.12 with Homebrew:  brew install python@3.12"
  echo "Then run ./start.sh again."
  exit 1
fi
command -v curl >/dev/null || { echo "curl not found."; exit 1; }
[ -f .env ] || cp .env.example .env
if lsof -iTCP:8000 -sTCP:LISTEN >/dev/null 2>&1; then
  echo "Port 8000 is already in use. Run ./stop.sh first, or close the other program."; exit 1
fi
if [ -d .venv ] && ! .venv/bin/python -c 'import sys; sys.exit(0 if sys.version_info[:2] in [(3,11),(3,12),(3,13)] else 1)' 2>/dev/null; then
  echo "Removing old virtual environment built with an unsupported Python..."
  rm -rf .venv
fi
[ -d .venv ] || "$PY" -m venv .venv
. .venv/bin/activate
pip install -q -r backend/requirements.txt
set -a; . ./.env; set +a
mkdir -p data

python -m uvicorn --app-dir backend app.main:app --host 127.0.0.1 --port 8000 &
PID=$!
trap 'kill $PID 2>/dev/null; echo "EcoLex AI stopped."; exit 0' INT TERM

READY=""
for i in $(seq 1 30); do
  if curl -fs http://127.0.0.1:8000/api/health >/dev/null 2>&1; then READY=1; break; fi
  sleep 1
done
if [ -z "$READY" ]; then echo "Backend did not start. Check the messages above."; kill $PID 2>/dev/null; exit 1; fi

echo ""
echo "========================================"
echo "           ECOLEX AI"
echo "========================================"
echo "Backend:  RUNNING (SQLite database at $DATABASE_PATH)"
echo "Gemini:   $( [ -n "$GEMINI_API_KEY" ] && echo 'key found' || echo 'NOT SET - add GEMINI_API_KEY to .env and restart' )"
echo ""
echo "Open in Google Chrome:  http://localhost:8000"
echo "API documentation:      http://localhost:8000/docs"
echo ""
echo "Keep this window open. Press Ctrl+C to stop."
wait $PID
