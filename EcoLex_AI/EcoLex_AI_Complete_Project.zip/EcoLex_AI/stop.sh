#!/usr/bin/env bash
# Stops EcoLex AI (local or Docker). Your data is kept.
cd "$(dirname "$0")"
pkill -f "uvicorn --app-dir backend" && echo "EcoLex AI stopped." || echo "EcoLex AI was not running locally."
docker compose down >/dev/null 2>&1 || true
