# EcoLex AI – Setup Guide for macOS

EcoLex AI lets citizens submit environmental complaints in English or Tamil. An AI model (Google Gemini) suggests a category, extracts details and finds related complaints. Its output is always an assessment, never a verified finding. Staff can review complaints, and a keyword search (BM25) plus AI answers work over an uploaded knowledge base.

## 1. Get a Gemini API key (one time)
1. Open https://aistudio.google.com/apikey in Chrome and create an API key.
2. Keep it private. You will paste it into a file on your Mac, not into any chat.

## 2. Extract the ZIP
Double-click `EcoLex_AI_Complete_Project.zip`. A folder named `EcoLex_AI` appears in Downloads.

## 3. Add your key
1. Open Terminal (Cmd + Space, type Terminal, press Enter).
2. Type: `cd ~/Downloads/EcoLex_AI` and press Enter.
3. Type: `cp .env.example .env` and press Enter.
4. Type: `open -e .env` and press Enter. TextEdit opens.
5. After `GEMINI_API_KEY=` paste your key, save with Cmd + S, and close TextEdit.

## 4. Start the application
EcoLex AI needs Python 3.11, 3.12 or 3.13. If `./start.sh` says Python is missing, run `brew install python@3.12` first (install Homebrew from https://brew.sh if needed).

In the same Terminal window, type:
```
chmod +x start.sh stop.sh
./start.sh
```
The first run takes a few minutes while Python libraries install. When you see the EcoLex AI banner, open **Google Chrome** and go to **http://localhost:8000**.

## 5. Use it
- Click **Log in** → **Switch login / register** → create an account.
- **Submit complaint** to file a complaint in English or Tamil.
- Open a complaint, then **Run AI analysis** and **Find related complaints**.
- **Dashboard** shows counts from the database. **Export CSV** on the complaints page downloads your list.
- **Knowledge assistant** answers questions from uploaded documents (see section 7).

## 6. Stop, restart, check
- Stop: press Ctrl + C in the Terminal window, or run `./stop.sh` in another window.
- Restart: `./start.sh`.
- Your data is kept in `data/ecolex.db` and is not deleted when you stop.

## 7. Staff roles and knowledge base
New accounts are citizens. To make an account a reviewer or admin, stop the app, then run:
```
sqlite3 data/ecolex.db "UPDATE users SET role='admin' WHERE email='you@example.com';"
```
Then start again. Staff can upload knowledge documents at http://localhost:8000/docs using `POST /api/knowledge` (click "Try it out"; log in first with `POST /api/auth/login` and use the token from the response in the Authorize button).

## 8. Back up and restore the database
- Backup: `cp data/ecolex.db ecolex_backup_$(date +%Y%m%d).db`
- Restore (app stopped): `cp ecolex_backup_YYYYMMDD.db data/ecolex.db`

## 9. Logs and troubleshooting
- "GEMINI_API_KEY is not set": open `.env`, paste the key, restart.
- "Gemini rate limit": wait a minute.
- "Port 8000 is already in use": run `./stop.sh`, then `./start.sh`.
- "python3 not found": run `xcode-select --install`.
- Errors print in the Terminal window where `./start.sh` runs.

## Docker alternative (optional)
With Docker Desktop running: `docker compose up --build`, then open http://localhost:8000.

## Known limits of this version
- SQLite database (PostgreSQL is not included in this version).
- Simple HTML interface, not a full React dashboard; no maps, PDF export, file uploads, email notifications, or Tamil interface translation.
- Cross-language matching is keyword based, so an English and a Tamil complaint about the same incident are not matched automatically.
- The Gemini model name may need changing in `.env` if Google retires it.
